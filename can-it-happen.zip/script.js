// Basic lighter spark effect placeholder
const canvas = document.getElementById('animationCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 400;
canvas.height = 200;

let sparks = [];
function createSpark() {
    return {
        x: canvas.width / 2,
        y: canvas.height / 2,
        dx: (Math.random() - 0.5) * 6,
        dy: (Math.random() - 1) * 6,
        life: 30
    };
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    sparks.forEach((spark, i) => {
        ctx.fillStyle = 'yellow';
        ctx.beginPath();
        ctx.arc(spark.x, spark.y, 2, 0, Math.PI * 2);
        ctx.fill();

        spark.x += spark.dx;
        spark.y += spark.dy;
        spark.life--;

        if (spark.life <= 0) sparks.splice(i, 1);
    });
}

function loop() {
    draw();
    requestAnimationFrame(loop);
}

setInterval(() => sparks.push(createSpark()), 100);
loop();
